#include "stdio.h"
#include "sys/socket.h"
#include "errno.h"
#include "netdb.h"
#include "string.h"
#include "stdlib.h"
 
 // Cuidado, está diseñado para Linux. Si se quiere compilar para ejecutar en sistemas Windows, las librerías y funciones de sockets cambian un poco.
int main(int argc , char **argv)
{
    struct hostent *host;
    int err, port , connection ,start , end;
    char hostname[100];
    struct sockaddr_in sa;
     
    //Host que se desea escanear
    printf("Introduce hostname o dirección IP : ");
    scanf("%s", &XXX1);
     
    //Puerto de inicio para el escaneo
    printf("\nPuerto de inicio: ");
    scanf("%d" , XXX2);
     
    //Puerto final para el escaneo
    XXX3
    XXX4
 
    //Inicializar la estructura sockaddr_in
    strncpy((char*)&sa , "" , sizeof sa);
    sa.sin_family = XXX5;
     
    //Dirección IP
    if(isdigit(hostname[0]))
    {
        printf("Doing inet_addr...");
        sa.sin_addr.s_addr = inet_addr(hostname);
        printf("Hecho\n");
    }
    //Resolución de nombre a IP
    else if( (host = gethostbyname(hostname)) != 0)
    {
        printf("Doing gethostbyname...");
        strncpy((char*)&sa.sin_addr , (char*)host -> h_addr , sizeof sa.sin_addr);
        printf("Hecho\n");
    }
    else
    {
        herror(hostname);
        exit(2);
    }
     
    //Bucle de escaneo de puertos
    printf("Comienza el escaneo de puertos... \n");
    for(XXX6) 
    {
        //Convertir el identificador de puerto
        sa.sin_port = htons(port);
        //Crear el socket
        connection = XXX7(AF_INET , SOCK_STREAM , 0);
         
        //Comprobar si el socket se ha creado correctamente
        if(connection < 0) 
        {
            perror("\nSocket");
            exit(1);
        }
        //Conectarse al socket creado
        err = connect(XXX8 , (struct sockaddr*)&sa , sizeof sa);
         
        //Si no se consigue realizar la conexión
        if( err < XXX9 )
        {
            //printf("%s %-5d %s\r" , hostname , i, strerror(errno));
            fflush(stdout);
        }
        //Si sí se consigue realizar la conexión
        else
        {
            printf("%-5d open\n",  port);
        }
		//Cerramos el socket
        close(XXX10);
    }
     
    printf("\r");
    fflush(stdout);
    return(0);
}