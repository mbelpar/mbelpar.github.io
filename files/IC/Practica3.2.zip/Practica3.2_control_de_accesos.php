<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST['XXX1']) && isset($_POST['XXX2']) && !empty($_POST['XXX1']) && !empty($_POST['XXX2'])) {

        $user = $_POST['XXX1'];
        $pass = $_POST['XXX2'];

        $conn = new mysqli('localhost', 'app', 'XXX3', 'XXX4');

        if ($conn->connect_error) {
                die("Falló la conexión a BBDD: " . $conn->connect_error);
        }

        $resultado = $conn->query("SELECT * FROM XXX5 WHERE XXX6 AND XXX7;");

        if ($resultado->XXX8){
                echo 'Usuario encontrado: Puedes acceder a la zona privada';
        } else {
                echo 'Usuario no encontrado: Vuelve a intentarlo';
        }

        XXX9->close();
} else {
        echo 'Introduce un usuario y una contraseña.';
}

?>